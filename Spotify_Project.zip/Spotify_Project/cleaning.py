import pandas as pd
df = pd.read_csv("spotify_data clean.csv")
print("Shape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nInfo:")
print(df.info())
before = df.shape[0]
df = df.drop_duplicates()
after = df.shape[0]
print(f"Duplicates removed: {before - after}")
print(df.isnull().sum())
df.drop_duplicates(inplace=True)
df['artist_name'].fillna('Unknown Artist', inplace=True)
df['artist_genres'].fillna('Unknown', inplace=True)
df['album_release_date'] = pd.to_datetime(df['album_release_date'], errors='coerce')
df['release_year'] = df['album_release_date'].dt.year
df['release_month'] = df['album_release_date'].dt.month
def popularity_band(pop):
    if pop >= 80:
        return 'High'
    elif pop >= 50:
        return 'Medium'
    else:
        return 'Low'
    df['popularity_band'] = df['track_popularity'].apply(popularity_band)
df['track_duration_sec'] = (df['track_duration_min'] * 60).astype(int)
print("Shape after cleaning:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nSample data:\n", df.head())
df.to_csv("spotify_data_cleaned_enriched.csv", index=False)
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
df = pd.read_csv("spotify_data_cleaned_enriched.csv")
print("Dataset shape:", df.shape)
print("Missing values:\n", df.isnull().sum())
print("\nSample data:\n", df.head())

# Top Tracks by Popularity
df_sorted_tracks = df.sort_values(by="track_popularity", ascending=False)
top_n_tracks = 5
df_top_tracks = df_sorted_tracks.head(top_n_tracks)
pastel_colors = np.random.rand(top_n_tracks, 3) * 0.5 + 0.5
plt.figure(figsize=(12,6))
plt.bar(df_top_tracks["track_name"], df_top_tracks["track_popularity"], color=pastel_colors)
plt.xticks(rotation=45, ha='right')
plt.title("Top 5 Tracks by Popularity (Pastel Colors)")
plt.xlabel("Track Name")
plt.ylabel("Popularity")
plt.tight_layout()
plt.show()

# Top Artists by Popularity
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
df = pd.read_csv("spotify_data_cleaned_enriched.csv")
print("Dataset shape:", df.shape)
print("Missing values:\n", df.isnull().sum())
print("\nSample data:\n", df.head())
top_artists = df.groupby("artist_name")["artist_popularity"].max().sort_values(ascending=False).head(10)
plt.figure(figsize=(12,6))
top_artists.plot(kind="bar", color=sns.color_palette("pastel"))
plt.title("Top 10 Artists by Popularity")
plt.xlabel("Artist")
plt.ylabel("Popularity")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# Distribution of Track Duration
plt.figure(figsize=(10,6))
sns.histplot(df['track_duration_min'], bins=30, kde=True, color="purple")
plt.title("Distribution of Track Duration (Minutes)")
plt.xlabel("Duration (Minutes)")
plt.ylabel("Number of Tracks")
plt.tight_layout()
plt.show()
# Explicit vs Non-Explicit Tracks
explicit_counts = df['explicit'].value_counts()
plt.figure(figsize=(6,6))
explicit_counts.plot(kind="pie", autopct='%1.1f%%', colors=["blue","lightpink"])
plt.title("Explicit vs Non-Explicit Tracks")
plt.ylabel("")
plt.tight_layout()
plt.show()

# Number of Tracks Released Per Year
yearly_releases = df.groupby("release_year")["track_id"].count()
plt.figure(figsize=(12,6))
yearly_releases.plot(kind="line", marker='o', color="lightcoral")
plt.title("Number of Tracks Released Per Year")
plt.xlabel("Year")
plt.ylabel("Number of Tracks")
plt.tight_layout()
plt.show()

# Top Genres Analysis
df_genres = df.copy()
df_genres["artist_genres"] = df_genres["artist_genres"].fillna("Unknown")
df_genres["artist_genres"] = df_genres["artist_genres"].apply(lambda x: [g.strip() for g in x.split(",")] if isinstance(x, str) else x)
df_exploded = df_genres.explode("artist_genres")
df_exploded = df_exploded[df_exploded["artist_genres"].str.lower() != "unknown"]
df_exploded = df_exploded[df_exploded["artist_genres"].str.strip() != ""]
genre_counts = df_exploded["artist_genres"].value_counts().head(10)
pastel_colors = sns.color_palette("pastel", len(genre_counts))
plt.figure(figsize=(12,6))
sns.barplot(x=genre_counts.values, y=genre_counts.index, palette=pastel_colors)
plt.title("Top 10 Most Common Music Genres")
plt.xlabel("Number of Tracks / Artists")
plt.ylabel("Genre")
plt.tight_layout()
plt.show()

