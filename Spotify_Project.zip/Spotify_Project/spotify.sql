SELECT * FROM spotify_tracks;
SELECT COUNT(*) AS total_tracks
FROM spotify_tracks;
SELECT artist_name, COUNT(*) AS track_count
FROM spotify_tracks
GROUP BY artist_name
ORDER BY track_count DESC
LIMIT 10;
SELECT track_name, track_popularity, artist_name
FROM spotify_tracks
ORDER BY track_popularity DESC
LIMIT 10;
SELECT artist_name, MAX(artist_popularity) AS max_popularity
FROM spotify_tracks
GROUP BY artist_name
ORDER BY max_popularity DESC
LIMIT 10;
SELECT release_year, COUNT(*) AS track_count
FROM spotify_tracks
GROUP BY release_year
ORDER BY release_year;
-- Split comma-separated genres
SELECT artist_genres, COUNT(*) AS count
FROM spotify_tracks
GROUP BY artist_genres
ORDER BY count DESC
LIMIT 10;

